import * as echarts from '../../lib/ec-canvas/echarts';

Page({
  data: {
    ec5: {
      lazyLoad: true // 延迟加载图表
    },
    ec6: {
      lazyLoad: true // 延迟加载图表
    },
    token:'version=2022-05-01&res=userid%2F326890&et=1918097402&method=sha1&sign=WmuTZbJic7zKijo620RjaxIVN9Y%3D',//用户密钥
    Noisetime: 0,//噪声采集时间
    Noise: 0,//噪声值
    noiseData: [], // 用于存储 Noise 数据的数组
    Noisemax: 0,
    Noisemaxtime: 0,
    Noisemaxtimeshow: '',
    maxNoise: {
      value: 0, // 初始最大值
      timestamp: 0, // 初始时间戳
    },
  },
  onLoad: function (options) {
    // 创建图表
    this.ec1Component = this.selectComponent('#mychart-dom-line'); // 选择页面中的 canvas 组件
    this.initChart_line(); // 调用初始化图表的函数
    // 获取图表的 canvas 对象
    this.ec2Component = this.selectComponent('#mychart-dom-gauge');
    this.initChart_gauge();

    // 初始化数据
    this.dataStore = {
      xAxisData: [],  // 不设置初始值
      seriesData: [], // 不设置初始值
    };
    this.currentTime = 0; // 当前时间，小时

    // 连接 MQTT
    this.connectToMQTT();
    setInterval(()=>{
      this.connectToMQTT();
    },800)
  },

  back:function (e) {
    wx.navigateTo({
      url: '/pages/index/index',
    })
  }, 

  connectToMQTT:function(){
    var that = this;
    wx.request({
      //url为新版onenet获取数据的api接口地址
      url: 'https://iot-api.heclouds.com/datapoint/history-datapoints',
      method:"GET",//方式为获取
      header:{
        "ccept":"application/json, text/plain, */*", // 指定请求头中的 Accept 字段,可以不加
        "authorization":that.data.token, //用户访问权限token
        "Content-Type": "application/json" // 指定请求体的数据类型为 JSON,可以不加
      },
      data:{
        "product_id":"qYAZf2aVV6", // 产品ID
        "device_name":"NoiseSys3", // 设备名称
        "datastream_id":"Noise", //数据流名称
        // "start":"2023-10-13T12:00:00", //开始时间
        // "limit":10, //获取数量
      },
      success:function (res) {
        console.log("success",res);
        that.setData({
          Noise:res.data.data.datastreams[0].datapoints[0].value,
          Noisetime:new Date(res.data.data.datastreams[0].datapoints[0].at).getTime(),
        }) 
        that.updateChart(that.data.Noise)
        console.log(that.data.Noisetime,that.data.Noise);
      }
    })
  },

  initChart_line: function() {
    this.ec1Component.init((canvas, width, height) => {
      const chart1 = echarts.init(canvas, null, {
        width: width,
        height: height,
      });
      canvas.setChart(chart1);
      // 初始数据
      this.chart1 = chart1; // 存储图表实例
      // 定义图表的选项配置
      this.option = {
        tooltip: {
          trigger: 'axis', // 鼠标悬停触发提示框，显示 x 轴和多个 y 轴数据项的信息
          position: function (pt) {
            return [pt[0], '10%'];
          },
          formatter: function (params) {
            var xAxisValue = params[0].axisValue; // 获取 x 轴的值
            var yValue = params[0].value; // 获取第一个 y 轴的值
            const date = new Date(parseInt(xAxisValue));
            // 自定义提示框的显示内容
            return '时间: ' + date.getHours().toString().padStart(2, '0') + ':' + date.getMinutes().toString().padStart(2, '0') + ':' + date.getSeconds().toString().padStart(2, '0') + '\n噪声值: ' + yValue + '';
          }
        },
        // 图例设置
        legend: {}, // 图例配置，可以为空，将根据系列的名称自动生成
        // 工具箱设置
        toolbox: {
          show: true, // 显示工具箱
          feature: {
            dataZoom: {
              yAxisIndex: 'none' // 允许在 y 轴上进行数据缩放
            },
            // dataView: { readOnly: false }, // 数据视图，允许用户查看原始数据
            magicType: { type: ['line', 'bar'] }, // 鼠标点击切换折线图和柱状图
            // restore: {}, // 还原图表视图
            // saveAsImage: {
            //   show: true, // 显示保存为图片按钮
            //   type:'png',
            //   title: '保存为图片', // 按钮标题
            //   pixelRatio: 2, // 保存图片的分辨率比例，设置为大于 1 的值
            // },
          }
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          // data: this.dataStore.xAxisData,
          data: this.data.Noisetime,
          axisLabel: {
            // interval: 0, // 强制显示所有刻度
            rotate: -45, // 刻度标签旋转角度
            formatter: function (value) {
              // 将时间戳转化为 "HH:MM:SS" 格式
              const date = new Date(parseInt(value));
              if (typeof value === 'number') {
                // 正确的时间戳
                const date = new Date(value);
                // console.log(date);
              } else {
                // console.log('Invalid timestamp:', value);
              }
              // console.log(date);
              return date.getHours().toString().padStart(2, '0') + ':' +
                     date.getMinutes().toString().padStart(2, '0') + ':' +
                     date.getSeconds().toString().padStart(2, '0');
            }
          },
        },
        yAxis: {
          name: '分贝值(dB)',
          type: 'value',
          boundaryGap: [0, '100%'],
          min: 0,  // 设置Y坐标轴的最小值
          max: 100, // 设置Y坐标轴的最大值
          axisLabel: {
            formatter: '{value}' // y 轴标签格式化，显示单位 dB
          }
        },
        dataZoom: [
          {
            type: 'inside',
            start: 0,
            end: 10
          },
          {
            start: 0,
            end: 10
          }
        ],
        series: [
          {
            name: '实时数据',
            type: 'line',
            // data: this.dataStore.seriesData,
            data: this.data.Noise,
            smooth: true,
            sampling: 'lttb',
            markPoint: { // 标记点设置
              data: [
                { type: 'max', name: 'Max' }, // 标记最大值点
                { type: 'min', name: 'Min' } // 标记最小值点
              ],
              symbol: 'circle', // 将标记点的形状设置为圆形
              symbolSize: 20, // 设置标记点的尺寸为 20
              itemStyle: {
                color: 'rgba(255, 255, 255, 0)' // 修改标记点的颜色为透明
              },
              areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  {
                    offset: 0,
                    color: 'rgb(255, 158, 68)'
                  },
                  {
                    offset: 1,
                    color: 'rgb(255, 70, 131)'
                  }
                ])
              },
              label: {
                show: true, // 显示标记点的文本标签
                position: 'top', // 文本标签显示在标记点内部
                fontSize: 18, // 文本标签的字体大小
                fontWeight: 'bold', // 文本标签的粗细
                color: 'red', // 文本标签的颜色
                formatter: function (params) {
                  // 只显示数字部分
                  return params.value + 'dB';
                }
              }    
            },
            markLine: { // 标记线设置
              data: [
                // { type: 'average', name: 'Avg' }// 标记平均值线
                {
                  type: 'max',
                  name: '最大值线',
                  yAxis: 40 // 设置标记线的 y 值为 15
                }
              ], 
              lineStyle: {
                color: 'red' // 修改标记线的颜色为红色
              }
            }
          },
        ],
      };
      chart1.setOption(this.option);
      return chart1;
    });
  },

  initChart_gauge: function() {
    this.ec2Component.init((canvas, width, height) => {
    const chart2 = echarts.init(canvas, null, {
      width: width,
      height: height
    });
    canvas.setChart(chart2);
    this.option = {
      series: [
        {
          // 第一个仪表盘
          type: 'gauge', // 设置图表类型为仪表盘
          center: ['50%', '60%'], // 设置仪表盘的中心位置
          startAngle: 200, // 设置起始角度
          endAngle: -20, // 设置结束角度
          min: 0, // 设置最小值
          max: 100, // 设置最大值
          splitNumber: 10, // 设置分隔线的数量
          itemStyle: {
            color: '#FD7347' // 仪表盘的颜色
          },
          progress: {
            show: true, // 显示进度条
            width: 20 // 进度条的宽度
          },
          pointer: {
            show: false // 隐藏指针
          },
          axisLine: {
            lineStyle: {
              width: 20 // 仪表盘轴线的宽度
            }
          },
          axisTick: {
            distance: -30, // 刻度线距离仪表盘的距离
            splitNumber: 5, // 刻度线的数量
            lineStyle: {
              width: 2,
              color: '#999' // 刻度线的样式
            }
          },
          splitLine: {
            distance: -35, // 分隔线距离仪表盘的距离
            length: 10, // 分隔线的长度
            lineStyle: {
              width: 3,
              color: '#999' // 分隔线的样式
            }
          },
          axisLabel: {
            distance: -10, // 刻度值距离仪表盘的距离
            color: '#999', // 刻度值的颜色
            fontSize: 16 // 刻度值的字体大小
          },
          anchor: {
            show: false // 隐藏锚点
          },
          title: {
            show: true // 隐藏标题
          },
          detail: {
            valueAnimation: true, // 启用值动画
            width: '60%', // 详情框的宽度
            lineHeight: 40, // 详情框的行高
            borderRadius: 8, // 详情框的边角半径
            offsetCenter: [0, '-15%'], // 详情框的位置偏移
            fontSize: 20, // 详情框的字体大小
            fontWeight: 'bold', // 详情框的字体粗细
            formatter: '{value} dB', // 详情框的显示格式
            color: 'inherit' // 详情框的文字颜色
          },
          data: [
            {
              value: 20 // 仪表盘的初始数值
            }
          ]
        },
        {
          // 第二个仪表盘，这是一个隐藏的仪表盘，没有可见元素
          type: 'gauge',
          center: ['50%', '60%'],
          startAngle: 200,
          endAngle: -20,
          min: 0,
          max: 100,
          itemStyle: {
            color: '#FD7347'
          },
          progress: {
            show: true,
            width: 8
          },
          pointer: {
            show: false
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          splitLine: {
            show: false
          },
          axisLabel: {
            show: false
          },
          detail: {
            show: false
          },
          data: [
            {
              value: 20
            }
          ]
        }
      ]
    };    
      // 将选项配置应用到图表中
      chart2.setOption(this.option);
      // 将图表实例存储在 data 中，以供后续使用
      this.chart2 = chart2;
      return chart2;
    });
  },
  updateChart: function (NoiseValue) {
    // 检查时间戳是否重复
    if (this.data.Noisetime === this.dataStore.xAxisData[this.dataStore.xAxisData.length - 1]) {
      return; // 如果时间戳重复，不刷新数据
    }
    // 更新 Noise 数据数组
    this.dataStore.seriesData[this.currentTime] = NoiseValue;
    this.data.noiseData.push(NoiseValue);
    // 更新 x 轴时间数据
    this.dataStore.xAxisData.push(this.data.Noisetime);
    //更新最大值
    this.updateMaxValue(this.data.Noise,this.data.Noisetime);
    // 更新图表
    this.chart1.setOption({
      xAxis: {
        data: this.dataStore.xAxisData,
      },
      series: [
        {
          data: this.data.noiseData,
        },
      ],
    });
    this.chart2.setOption({
      series: [
        {
          data: [
            {
              value: this.data.Noise
            }
          ]
        },
        {
          data: [
            {
              value: this.data.Noise
            }
          ]
        }
      ]
    });
  },  
  updateMaxValue: function (newValue,timestamp) {
    if (newValue > this.data.maxNoise.value) {
      // maxValue = newValue;
      this.setData({
        'maxNoise.value': newValue,
        'maxNoise.timestamp': timestamp
      })
    }
    const date = new Date(parseInt(this.data.maxNoise.timestamp));
    this.setData({
      Noisemaxtimeshow:date.getHours().toString().padStart(2, '0') + ':' + date.getMinutes().toString().padStart(2, '0') + ':' + date.getSeconds().toString().padStart(2, '0')
    })
  }
})