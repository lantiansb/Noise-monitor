Page({

  /**
   * 页面的初始数据
   */
  data: {
    token:'version=2022-05-01&res=userid%2F326890&et=1918097402&method=sha1&sign=WmuTZbJic7zKijo620RjaxIVN9Y%3D',//用户密钥
    device1name: '噪声监测设备1',
    device1time: '2013-10-25',
    device1noise: 0,
    device1connect: '',
    device1power: '',
    // device2
    device2name: '噪声监测设备2',
    device2time: '2013-10-25',
    device2noise: 0,
    device2connect: '',
    device2power: '',
    // device3
    device3name: '噪声监测设备3',
    device3time: '2013-10-25',
    device3noise: 0,
    device3connect: '',
    device3power: '',
    // device4
    device4name: '噪声监测设备4',
    device4time: '2013-10-25',
    device4noise: 0,
    device4connect: '',
    device4power: '',
  },

  naviDevice1(e){
    wx.navigateTo({
      url: '/pages/devices/devices',
    })
    // wx.switchTab({
    //   url: '/pages/devices/devices',
    // })
  },
  naviDevice2(e){
    wx.navigateTo({
      url: '/pages/devices2/devices2',
    })
  },
  naviDevice3(e){
    wx.navigateTo({
      url: '/pages/devices3/devices3',
    })
  },
  naviDevice4(e){
    wx.navigateTo({
      url: '/pages/devices4/devices4',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    setInterval(()=>{
      this.connectToMQTT()
      this.connectToMQTT2()
      this.connectToMQTT3()
      this.connectToMQTT4()
    },1000)
  },
  connectToMQTT:function(){
    var that = this;
    wx.request({
      //url为新版onenet获取数据的api接口地址
      url: 'https://iot-api.heclouds.com/datapoint/history-datapoints',
      method:"GET",//方式为获取
      header:{
        "ccept":"application/json, text/plain, */*", // 指定请求头中的 Accept 字段,可以不加
        "authorization":that.data.token, //用户访问权限token
        "Content-Type": "application/json" // 指定请求体的数据类型为 JSON,可以不加
      },
      data:{
        "product_id":"qYAZf2aVV6", // 产品ID
        "device_name":"NoiseSys", // 设备名称
        "datastream_id":"Noise", //数据流名称
      },
      success:function (res) {
        // console.log("success",res);
        that.setData({
          // device1name:device_name,
          device1noise:res.data.data.datastreams[0].datapoints[0].value,
          device1time:res.data.data.datastreams[0].datapoints[0].at
        }) 
      }
    })
  },
  connectToMQTT2:function(){
    var that = this;
    wx.request({
      //url为新版onenet获取数据的api接口地址
      url: 'https://iot-api.heclouds.com/datapoint/history-datapoints',
      method:"GET",//方式为获取
      header:{
        "ccept":"application/json, text/plain, */*", // 指定请求头中的 Accept 字段,可以不加
        "authorization":that.data.token, //用户访问权限token
        "Content-Type": "application/json" // 指定请求体的数据类型为 JSON,可以不加
      },
      data:{
        "product_id":"qYAZf2aVV6", // 产品ID
        "device_name":"NoiseSys2", // 设备名称
        "datastream_id":"Noise", //数据流名称
        // "start":"2023-10-13T12:00:00", //开始时间
        // "limit":10, //获取数量
      },
      success:function (res) {
        // console.log("success",res);
        that.setData({
          // device1name:device_name,
          device2noise:res.data.data.datastreams[0].datapoints[0].value,
          device2time:res.data.data.datastreams[0].datapoints[0].at
        }) 
      }
    })
  },
  connectToMQTT3:function(){
    var that = this;
    wx.request({
      //url为新版onenet获取数据的api接口地址
      url: 'https://iot-api.heclouds.com/datapoint/history-datapoints',
      method:"GET",//方式为获取
      header:{
        "ccept":"application/json, text/plain, */*", // 指定请求头中的 Accept 字段,可以不加
        "authorization":that.data.token, //用户访问权限token
        "Content-Type": "application/json" // 指定请求体的数据类型为 JSON,可以不加
      },
      data:{
        "product_id":"qYAZf2aVV6", // 产品ID
        "device_name":"NoiseSys3", // 设备名称
        "datastream_id":"Noise", //数据流名称
        // "start":"2023-10-13T12:00:00", //开始时间
        // "limit":10, //获取数量
      },
      success:function (res) {
        // console.log("success",res);
        that.setData({
          // device1name:device_name,
          device3noise:res.data.data.datastreams[0].datapoints[0].value,
          device3time:res.data.data.datastreams[0].datapoints[0].at
        }) 
      }
    })
  },
  connectToMQTT4:function(){
    var that = this;
    wx.request({
      //url为新版onenet获取数据的api接口地址
      url: 'https://iot-api.heclouds.com/datapoint/history-datapoints',
      method:"GET",//方式为获取
      header:{
        "ccept":"application/json, text/plain, */*", // 指定请求头中的 Accept 字段,可以不加
        "authorization":that.data.token, //用户访问权限token
        "Content-Type": "application/json" // 指定请求体的数据类型为 JSON,可以不加
      },
      data:{
        "product_id":"qYAZf2aVV6", // 产品ID
        "device_name":"NoiseSys4", // 设备名称
        "datastream_id":"Noise", //数据流名称
        // "start":"2023-10-13T12:00:00", //开始时间
        // "limit":10, //获取数量
      },
      success:function (res) {
        // console.log("success",res);
        that.setData({
          // device1name:device_name,
          device4noise:res.data.data.datastreams[0].datapoints[0].value,
          device4time:res.data.data.datastreams[0].datapoints[0].at
        }) 
      }
    })
  },
})